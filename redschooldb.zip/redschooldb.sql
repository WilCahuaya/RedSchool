-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 08-11-2022 a las 23:57:44
-- Versión del servidor: 10.5.17-MariaDB-cll-lve
-- Versión de PHP: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `redschooldb`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `classrooms`
--

CREATE TABLE `classrooms` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `grade` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `classrooms`
--

INSERT INTO `classrooms` (`id`, `grade`, `section`, `is_active`, `created_at`, `updated_at`) VALUES
(1, '1', 'a', 1, '2022-06-07 22:03:21', '2022-06-07 22:03:21'),
(2, '1', 'b', 1, '2022-06-07 22:03:21', '2022-06-07 22:03:21'),
(3, '1', 'c', 1, '2022-06-07 22:03:21', '2022-06-07 22:03:21'),
(4, '1', 'd', 1, '2022-06-07 22:03:21', '2022-06-07 22:03:21'),
(5, '1', 'e', 1, '2022-06-07 22:03:21', '2022-06-07 22:03:21'),
(6, '2', 'a', 1, '2022-06-07 22:03:21', '2022-06-07 22:03:21'),
(7, '2', 'b', 1, '2022-06-07 22:03:21', '2022-06-07 22:03:21'),
(8, '2', 'c', 1, '2022-06-07 22:03:21', '2022-06-07 22:03:21'),
(9, '2', 'd', 1, '2022-06-07 22:03:21', '2022-06-07 22:03:21'),
(10, '2', 'e', 1, '2022-06-07 22:03:21', '2022-06-07 22:03:21'),
(11, '3', 'a', 1, '2022-06-07 22:03:21', '2022-06-07 22:03:21'),
(12, '3', 'b', 1, '2022-06-07 22:03:21', '2022-06-07 22:03:21'),
(13, '3', 'c', 1, '2022-06-07 22:03:21', '2022-06-07 22:03:21'),
(14, '3', 'd', 1, '2022-06-07 22:03:21', '2022-06-07 22:03:21'),
(15, '3', 'e', 1, '2022-06-07 22:03:21', '2022-06-07 22:03:21'),
(16, '4', 'a', 1, '2022-06-07 22:03:21', '2022-06-07 22:03:21'),
(17, '4', 'b', 1, '2022-06-07 22:03:21', '2022-06-07 22:03:21'),
(18, '4', 'c', 1, '2022-06-07 22:03:21', '2022-06-07 22:03:21'),
(19, '4', 'd', 1, '2022-06-07 22:03:21', '2022-06-07 22:03:21'),
(20, '4', 'e', 1, '2022-06-07 22:03:21', '2022-06-07 22:03:21'),
(21, '5', 'a', 1, '2022-06-07 22:03:21', '2022-06-07 22:03:21'),
(22, '5', 'b', 1, '2022-06-07 22:03:21', '2022-06-07 22:03:21'),
(23, '5', 'c', 1, '2022-06-07 22:03:21', '2022-06-07 22:03:21'),
(24, '5', 'd', 1, '2022-06-07 22:03:21', '2022-06-07 22:03:21'),
(25, '5', 'e', 1, '2022-06-07 22:03:21', '2022-06-07 22:03:21');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `courses`
--

CREATE TABLE `courses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `teachers_id` bigint(20) UNSIGNED DEFAULT NULL,
  `classrooms_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `courses`
--

INSERT INTO `courses` (`id`, `name`, `teachers_id`, `classrooms_id`, `created_at`, `updated_at`) VALUES
(2, 'Comunicación CO', 1, 1, '2022-06-07 22:06:04', '2022-07-07 22:41:07'),
(41, 'Comunicación CO', 1, 5, '2022-07-05 23:00:02', '2022-07-07 22:41:22'),
(40, 'Comunicación CO', 1, 4, '2022-07-05 22:59:51', '2022-07-07 22:41:31'),
(5, 'Ciencias Sociales CS', 10, 1, '2022-06-08 21:49:24', '2022-07-07 18:27:29'),
(6, 'Desarrollo Personal Ciudadana y Cívica DP', 13, 1, '2022-06-08 21:55:30', '2022-07-07 18:27:46'),
(7, 'Educación para el Trabajo ET', 16, 1, '2022-06-08 21:56:16', '2022-07-07 18:28:00'),
(8, 'Educación Física EF', 19, 1, '2022-06-08 21:57:06', '2022-07-07 18:28:14'),
(9, 'Educación Religiosa ER', 22, 1, '2022-06-08 21:57:36', '2022-07-07 18:28:30'),
(10, 'Arte y Cultura AC', 26, 1, '2022-06-08 21:58:25', '2022-07-07 18:29:26'),
(39, 'Comunicación CO', 1, 3, '2022-07-05 22:59:34', '2022-07-07 22:42:03'),
(12, 'Matemática MA', 6, 2, '2022-06-08 21:59:33', '2022-07-07 18:30:54'),
(13, 'Ciencia y Tecnología CT', 7, 2, '2022-06-08 22:00:44', '2022-07-07 18:31:11'),
(14, 'Ciencias Sociales CS', 10, 2, '2022-06-08 22:01:03', '2022-07-07 18:31:34'),
(15, 'Desarrollo Personal Ciudadana y Cívica DP', 13, 2, '2022-06-08 22:01:32', '2022-07-07 18:32:13'),
(16, 'Educación para el Trabajo ET', 16, 2, '2022-06-08 22:01:46', '2022-07-07 18:32:33'),
(17, 'Educación Física EF', 19, 2, '2022-06-08 22:02:07', '2022-07-07 18:32:55'),
(18, 'Educación Religiosa ER', 22, 2, '2022-06-08 22:02:34', '2022-07-07 18:33:15'),
(19, 'Arte y Cultura AC', 26, 2, '2022-06-08 22:03:10', '2022-07-07 18:33:40'),
(20, 'Ingles IN', 28, 2, '2022-06-08 22:03:33', '2022-07-07 18:34:10'),
(38, 'Comunicación CO', 1, 2, '2022-07-05 22:59:26', '2022-07-07 22:42:14'),
(22, 'Matemática MA', 6, 1, '2022-06-08 22:37:13', '2022-07-07 18:34:53'),
(23, 'Ciencia y Tecnología CT', 7, 3, '2022-06-08 22:37:26', '2022-07-07 18:35:25'),
(24, 'Ciencias Sociales CS', 10, 3, '2022-06-08 22:37:43', '2022-07-07 18:35:40'),
(25, 'Desarrollo Personal Ciudadana y Cívica DP', 13, 3, '2022-06-08 22:37:59', '2022-07-07 18:36:01'),
(42, 'Matemática MA', 6, 4, '2022-07-05 23:00:29', '2022-07-07 18:36:30'),
(43, 'Matemática MA', 6, 5, '2022-07-05 23:00:43', '2022-07-07 18:36:52'),
(44, 'Arte y Cultura AC', 26, 4, '2022-07-05 23:01:05', '2022-07-07 18:37:14'),
(29, 'Arte y Cultura AC', 26, 3, '2022-06-08 22:39:50', '2022-07-07 18:37:38'),
(45, 'Arte y Cultura AC', 26, 5, '2022-07-05 23:01:18', '2022-07-07 18:38:00'),
(34, 'Matemática MA', 6, 3, '2022-07-05 22:40:13', '2022-07-07 18:38:16'),
(33, 'Matemática MA', 6, 2, '2022-07-05 22:39:54', '2022-07-07 18:38:31'),
(47, 'Educacion Fisica EF', 31, 11, '2022-09-20 19:04:51', '2022-09-20 19:12:39'),
(48, 'Algebra AG', 32, 11, '2022-09-20 19:25:12', '2022-09-20 19:25:12'),
(49, 'Matemática MA', 33, 21, '2022-09-30 20:12:28', '2022-09-30 20:48:33'),
(50, 'Matemática MA', 34, 22, '2022-09-30 20:12:57', '2022-09-30 20:48:17'),
(51, 'Educación por el Trabajo ET', 35, 1, '2022-09-30 20:16:32', '2022-09-30 20:47:31'),
(52, 'Educación por el Trabajo ET', 36, 2, '2022-09-30 20:16:53', '2022-09-30 20:47:12'),
(53, 'Comucación CO', 37, 6, '2022-09-30 20:22:18', '2022-09-30 20:45:55'),
(54, 'Educación por el Trabajo ET', 38, 6, '2022-09-30 20:22:34', '2022-09-30 20:45:29'),
(55, 'Matemática MA', 39, 11, '2022-09-30 20:23:14', '2022-09-30 20:44:31'),
(56, 'Matemática MA', 40, 12, '2022-09-30 20:23:30', '2022-09-30 20:43:59'),
(57, 'Educación por el Trabajo ET', 41, 16, '2022-09-30 20:23:48', '2022-09-30 20:43:33'),
(58, 'Educación por el Trabajo ET', 42, 17, '2022-09-30 20:29:23', '2022-09-30 20:42:28');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `labors`
--

CREATE TABLE `labors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reception_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` int(11) NOT NULL,
  `feedback` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `delivery_date` date NOT NULL,
  `students_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `labors`
--

INSERT INTO `labors` (`id`, `photo`, `reception_code`, `note`, `feedback`, `delivery_date`, `students_id`, `created_at`, `updated_at`) VALUES
(60, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MM60708ef1c37efbbc8e392c0ee695fb4f/Media/ME62b366494e7f1a6de070d694d4a5e5b3', 'AC1B00009', 17, 'Gracias', '2022-09-23', 18, '2022-09-23 17:58:56', '2022-09-23 17:59:20'),
(59, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MM05fa2255d6218bc7548dc46cfef9edc6/Media/MEc321b51c6376b95f551463f8f13fa1a5', 'AC1B00011', 12, 'AAAAAA', '2022-09-23', 18, '2022-09-23 17:32:26', '2022-09-23 17:32:54'),
(41, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MMd5ff21694bf9c3432daf5c68e67e0234/Media/ME71909b94e376f385e83a938cae9e381a', '', 0, '---', '2022-08-30', 2, '2022-08-30 05:28:01', '2022-08-30 05:28:01'),
(58, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MM25c00aaa0d0298e8e34d23d3e8b53628/Media/ME23a98766106e077c915f79ea02ab8fea', 'AC1B00012', 16, 'Muy Bien', '2022-09-23', 18, '2022-09-23 17:26:50', '2022-09-23 20:07:09'),
(43, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MM1db132d2f60fc29042ed420414f8d5d2/Media/MEb6ea5bea50054d0d40ee3af21db222e4', '2022391984-1-71313177.pdf', 0, '---', '2022-08-30', 2, '2022-08-30 05:31:28', '2022-08-30 05:31:28'),
(44, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MMf583cd3ec2e273f9981d546cd8bf87f7/Media/ME53dde5a60acc0360e089e29aad245fda', 'Ma1a0001', 0, '---', '2022-09-20', 2, '2022-09-20 18:35:16', '2022-09-20 18:35:16'),
(45, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MMc9b1685da2973d1c9d9ca2da43b12d1e/Media/ME8c7a98ac71c18e2440f61215efc61604', 'MA1A00001', 20, 'Que bueno que hayas cumplido tu tarea. Felicidades', '2022-09-20', 2, '2022-09-20 18:36:45', '2022-09-20 18:37:35'),
(46, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MM346adf0b85b81518d622e8422aafb97a/Media/ME2239ff01b40cccff9c085002bfb9cf31', 'EF3A00001', 12, 'Muy Bien', '2022-09-20', 18, '2022-09-20 19:18:00', '2022-09-20 19:18:47'),
(47, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MM7e5934a75e197a9f4f5031df70741b2c/Media/ME38a2d16089636bffdf0c377c1dd020a4', 'AG3A00001', 12, 'Muy Bien', '2022-09-20', 18, '2022-09-20 19:30:45', '2022-09-20 19:31:13'),
(48, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MM05740f4179b0eb386be51bb551177b39/Media/ME48be86a932c58bcf8eb8d85d62bbad3b', 'AG3A00002', 16, 'Muy bien', '2022-09-20', 18, '2022-09-20 21:35:38', '2022-09-20 21:37:13'),
(61, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MM49f2312ad67b4ce973c6e262900cac6e/Media/MEc1ce2f5500fd18d4ee8c6079fe431618', 'AC1B00013', 0, '---', '2022-09-23', 18, '2022-09-23 20:05:51', '2022-09-23 20:05:51'),
(50, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MM78fc5ee8522de27ba0be18a0e9549a42/Media/ME68a1b8543fc9fb1d371d48bfbf0903c7', 'AC1B00006', 15, 'Falta la 3', '2022-09-21', 18, '2022-09-21 17:21:46', '2022-09-21 17:24:04'),
(51, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MM5f98f19ab4e615c27293ace0c6e9728a/Media/ME9c36bab25c7fff8c37d856acb9de9ae5', 'AC1B00009', 16, 'Muy bien', '2022-09-22', 6, '2022-09-22 20:28:13', '2022-09-22 21:22:59'),
(52, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MM6aed798764a173071ebe4afc51f46e8d/Media/MEae85f91f84f0e8543d183154e1d2e79a', 'aprueban-reglamento-de-la-ley-n-30299-ley-de-armas-de-fueg-decreto-supremo-n-008-2016-in-1400743-1.pdf', 0, '---', '2022-09-22', 6, '2022-09-22 20:30:54', '2022-09-22 20:30:54'),
(53, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MM6a5aae91a3c79db7834f831c8654bd5b/Media/ME92f285054e336f1efb77c5b47da9600e', '', 0, '---', '2022-09-22', 10, '2022-09-22 21:24:36', '2022-09-22 21:24:36'),
(54, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MM79b52d641e4a1f06128f6b9a0f5f7018/Media/MEf6430066a3474c2a7449b2804e35af55', 'AC1B00010', 20, 'Muy bien hecho', '2022-09-22', 10, '2022-09-22 21:25:13', '2022-09-22 21:25:44'),
(55, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MM10d31007de14178e6a83d999d7fa22ee/Media/ME3f7e1e0e4dae64c23d6b3ca9a6c36092', 'AC1B00011', 17, 'Muy bien', '2022-09-22', 10, '2022-09-22 21:42:57', '2022-09-22 21:43:55'),
(56, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MMc65dd4e5a6b806a7c6df49c2d14208a3/Media/MEc7db5c029890e09a036fd184e6bbb8e7', '', 0, '---', '2022-09-22', 10, '2022-09-23 00:18:16', '2022-09-23 00:18:16'),
(57, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MMe8ca510693db2cea9babeacacd8ebb2d/Media/ME4e63d4f6b6587e0ad638e32c30da9696', 'AC1B00012', 12, 'Muy bien', '2022-09-22', 10, '2022-09-23 00:20:03', '2022-09-23 00:22:29'),
(62, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MM0cb2c79514275acaa236963cf07ab259/Media/ME6e7eccfbdc5212dda9a56c49a29decad', 'AC1A00021', 15, 'Yuri', '2022-09-28', 18, '2022-09-29 01:20:18', '2022-09-29 01:20:42'),
(63, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MM51e074cceee440032a1ee97d5e35cc14/Media/ME9d3e0abd54515958e8fc8a62178ee994', 'CO2A00001', 20, 'Muy bien te felicito', '2022-09-30', 18, '2022-09-30 21:34:40', '2022-09-30 21:38:30'),
(64, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MM0fd492b9408da2d20365fdb26a4c3d0f/Media/MEf60513d3101476cc3055251dcea82eba', 'ET2A00001', 0, '---', '2022-09-30', 18, '2022-09-30 22:11:42', '2022-09-30 22:11:42'),
(65, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MM732ccbaac5497377ce1ed8d56589b3b1/Media/ME6c1377648c477a6f4db6aea3236bca0a', 'MA5A00001', 15, 'Fallaste la 3 y la 7. Las alternativas correctas son B y la A respectivamente.', '2022-09-30', 18, '2022-09-30 23:01:09', '2022-09-30 23:03:36'),
(66, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MMa90582c2d2b68ef5afcf5c677c8478cf/Media/MEbf0a0e373e3199ff82f22f2d8776f8c8', 'MA5B00001', 20, 'Muy bien hacertaste todas las preguntas.', '2022-09-30', 18, '2022-09-30 23:13:26', '2022-09-30 23:15:02'),
(67, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MMadda50038e4431ea9cbed289cc00b837/Media/ME260e28ef2075dc3c64ff127d1ba1ebcb', 'ET1A00001', 0, 'No relleno nada', '2022-09-30', 18, '2022-10-01 00:07:35', '2022-10-01 00:09:18'),
(68, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MMcbac42a42d202d5a2d34b4afcc066c18/Media/MEa7c6b982725b2a902a1e4e554cd5ef6d', 'ET1B00001', 13, 'La RAM es la zona de trabajo del CPU.', '2022-09-30', 18, '2022-10-01 00:18:44', '2022-10-01 00:21:17'),
(69, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MMaf5149462ba2a97c058c2d59bebbc74e/Media/ME08eee8ef9b338947fb5dc92856b25297', '', 0, '---', '2022-09-30', 18, '2022-10-01 00:19:00', '2022-10-01 00:19:00'),
(70, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MM3b4d91699b1b1a2d475d88dac8b87b97/Media/ME8cff51a1bbb6b90f80e6380338ded32e', '', 0, '---', '2022-09-30', 18, '2022-10-01 00:21:32', '2022-10-01 00:21:32'),
(71, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MMdba6a8112436ddf96fa06a7c117696c8/Media/MEb4328b0abe6d1e3e797c511c1d01e107', 'ET4B00001', 19, 'Muy bien alumno', '2022-09-30', 18, '2022-10-01 00:34:44', '2022-10-01 00:36:04'),
(72, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MMb598142e354937e2967e9576b84ba26a/Media/MEf0fbdc8321a7a789520aebc05287a76b', 'ET4A00001', 17, 'Traer impreso para el dia Lunes me srvira de muestra para tus compañeros.', '2022-09-30', 18, '2022-10-01 00:44:04', '2022-10-01 00:45:26'),
(73, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MM72ebc28449af16862bf28adc0e24b5ca/Media/ME196db9f7155e31f67d9ead4d07ca8a02', 'MA3B00001', 8, 'Falta Completar si desea mas nota lo trae resuelto para la siguiente clase.', '2022-09-30', 18, '2022-10-01 00:58:05', '2022-10-01 00:59:22'),
(74, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MM8a1da47dac885df4783ca3b4d7994bb9/Media/MEf7d239ddc62c87628b9e82866ea18f78', 'MA3A00001', 14, 'Vuelvelo a intentar y en clase lo comparamos con las respuestas.', '2022-09-30', 18, '2022-10-01 01:06:44', '2022-10-01 01:08:07'),
(75, 'https://api.twilio.com/2010-04-01/Accounts/AC9c4872acc6d847280b8b531767b41636/Messages/MM8639e277cfd349e5380db429e861aef0/Media/MEdb976d5a84f2f180e39a61c88eb8fd7d', '', 0, '---', '2022-09-30', 18, '2022-10-01 01:08:29', '2022-10-01 01:08:29');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_05_06_113049_create_classrooms_table', 1),
(6, '2022_05_06_123313_create_teachers_table', 1),
(7, '2022_05_17_202926_create_tutors_table', 1),
(8, '2022_05_18_041611_create_students_table', 1),
(9, '2022_05_31_200218_create_roles_table', 1),
(10, '2022_05_31_222956_add_roles_id_to_users_table', 1),
(11, '2022_06_01_235210_create_tasks_table', 1),
(12, '2022_06_02_024000_create_courses_table', 1),
(13, '2022_06_02_044631_add_courses_id_to_tasks_table', 1),
(14, '2022_06_08_232039_create_student_course_table', 2),
(15, '2022_06_09_033847_create_labors_table', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('cavila@salesiano.edu.pe', '$2y$10$3xuUEQ4tb0yw9KLvP8uFZuVlUMe1b703O3ExYOaoZxoNrqTqr6opq', '2022-09-29 02:23:59');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'administrador', '2022-06-04 03:03:10', '2022-06-04 03:03:10'),
(2, 'docente', '2022-06-04 08:04:15', '2022-06-04 08:04:15');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `students`
--

CREATE TABLE `students` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `DNI` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `tutors_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `students`
--

INSERT INTO `students` (`id`, `DNI`, `name`, `surname`, `email`, `number_phone`, `is_active`, `created_at`, `updated_at`, `tutors_id`) VALUES
(1, '45278478', 'Luis', 'Marquez Medina', 'mmedina@admin.com', '985075184', 1, '2022-06-07 22:02:41', '2022-06-08 21:45:29', 8),
(2, '48217068', 'Wilder', 'Medina Lazo', 'wcahuayaquispe@gmail.com', '947878789', 0, '2022-06-07 22:02:41', '2022-09-23 18:00:56', 1),
(3, '44578914', 'Rosa', 'Paucar Barzola', 'pbarzola@admin.com', '965245879', 1, '2022-06-07 22:02:41', '2022-06-08 21:45:50', 9),
(4, '24578146', 'Jhony', 'Taboada Ruiz', 'truiz@admin.com', '999225478', 1, '2022-06-07 22:02:41', '2022-06-08 21:46:23', 12),
(5, '45781436', 'Cielo', 'Marcos Damas', 'mdamas@admin.com', '985745863', 1, '2022-06-07 22:02:41', '2022-06-08 21:45:16', 7),
(6, '74369837', 'Jimmy', 'Jiménez Cerrón', 'jjimenez@gmail.com', '947375032', 1, '2022-06-07 22:02:41', '2022-06-17 03:56:57', 5),
(7, '45248779', 'Juan', 'Quispe Perez', 'qperez@admin.com', '942615378', 1, '2022-06-07 22:02:41', '2022-06-08 21:46:16', 11),
(8, '75417456', 'Paul', 'Serva Yantas', 'jserva@gmail.com', '985075184', 1, '2022-06-07 22:02:41', '2022-06-17 01:14:10', 4),
(9, '45217869', 'Hair', 'Gutarra Tobar', 'gtobar@admin.com', '986145237', 1, '2022-06-07 22:02:41', '2022-06-08 21:45:00', 6),
(10, '24578968', 'Luis', 'Saldaña', 'qatoc@admin.com', '998875820', 1, '2022-06-07 22:02:41', '2022-08-30 05:37:44', 10),
(11, '48962578', 'Miguel', 'Alfaro Mendez', 'amendez@admin.com', '965848578', 0, '2022-06-29 02:17:38', '2022-06-29 02:53:03', 1),
(12, '24578917', 'Maria', 'Barzola Quispe', 'bquispe@admin.com', '915236478', 1, '2022-06-29 02:17:38', '2022-06-29 02:17:38', 1),
(13, '24581369', 'Elsa', 'Aquino Inga', 'ainga@admin.com', '965723845', 1, '2022-06-29 02:17:38', '2022-06-29 02:17:38', 1),
(17, '72345654', 'Mario', 'Espinoza Soto', 'mespinoza@gmail.com', '965568578', 1, '2022-06-29 02:52:35', '2022-06-29 02:52:35', 1),
(16, '48768759', 'Antony', 'Porras Rojas', 'aporras@gmail.com', '985455184', 1, '2022-06-29 02:52:35', '2022-06-29 02:52:35', 1),
(18, '26767656', 'Wilder', 'Cahuaya Quispe', 'wcahuaya@gmail.com', '998608345', 1, '2022-09-20 18:58:15', '2022-09-23 17:29:31', 11);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `student_course`
--

CREATE TABLE `student_course` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `students_id` bigint(20) UNSIGNED DEFAULT NULL,
  `courses_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `student_course`
--

INSERT INTO `student_course` (`id`, `students_id`, `courses_id`, `created_at`, `updated_at`) VALUES
(20, 4, 38, '2022-07-07 23:56:32', '2022-07-07 23:56:32'),
(46, 18, 58, '2022-09-30 21:12:50', '2022-09-30 21:12:50'),
(10, 4, 19, '2022-06-21 20:45:48', '2022-06-21 20:45:48'),
(15, 9, 29, '2022-06-21 20:55:01', '2022-06-21 20:55:01'),
(14, 7, 29, '2022-06-21 20:54:47', '2022-06-21 20:54:47'),
(45, 18, 19, '2022-09-23 17:42:53', '2022-09-23 17:42:53'),
(8, 6, 19, '2022-06-21 20:43:07', '2022-07-08 05:14:09'),
(13, 5, 29, '2022-06-21 20:54:04', '2022-06-21 20:54:04'),
(12, 8, 10, '2022-06-21 20:53:14', '2022-06-21 20:53:14'),
(16, 10, 19, '2022-06-21 20:55:24', '2022-06-21 20:55:24'),
(49, 18, 55, '2022-09-30 21:13:21', '2022-09-30 21:13:21'),
(22, 10, 38, '2022-07-07 23:57:17', '2022-07-07 23:57:17'),
(37, 4, 12, '2022-07-08 00:31:23', '2022-07-08 00:31:23'),
(38, 10, 12, '2022-07-08 00:32:21', '2022-07-08 00:32:21'),
(26, 6, 2, '2022-07-07 23:59:27', '2022-07-07 23:59:27'),
(27, 8, 2, '2022-07-07 23:59:38', '2022-07-07 23:59:38'),
(28, 6, 22, '2022-07-08 00:00:21', '2022-07-08 00:00:21'),
(29, 8, 22, '2022-07-08 00:00:36', '2022-07-08 00:00:36'),
(30, 9, 39, '2022-07-08 00:01:28', '2022-07-08 00:01:28'),
(31, 9, 34, '2022-07-08 00:01:46', '2022-07-08 00:01:46'),
(32, 7, 39, '2022-07-08 00:01:59', '2022-07-08 00:01:59'),
(33, 7, 34, '2022-07-08 00:02:09', '2022-07-08 00:02:09'),
(34, 5, 39, '2022-07-08 00:02:27', '2022-07-08 00:02:27'),
(35, 5, 34, '2022-07-08 00:02:39', '2022-07-08 00:02:39'),
(47, 18, 57, '2022-09-30 21:13:01', '2022-09-30 21:13:01'),
(48, 18, 56, '2022-09-30 21:13:10', '2022-09-30 21:13:10'),
(50, 18, 54, '2022-09-30 21:15:02', '2022-09-30 21:15:02'),
(51, 18, 53, '2022-09-30 21:15:14', '2022-09-30 21:15:14'),
(52, 18, 52, '2022-09-30 21:15:37', '2022-09-30 21:15:37'),
(53, 18, 51, '2022-09-30 21:15:50', '2022-09-30 21:15:50'),
(54, 18, 50, '2022-09-30 21:16:11', '2022-09-30 21:16:11'),
(55, 18, 49, '2022-09-30 21:16:22', '2022-09-30 21:16:22');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tasks`
--

CREATE TABLE `tasks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `reception_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_date` date NOT NULL,
  `delivery_date` date NOT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `courses_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `tasks`
--

INSERT INTO `tasks` (`id`, `reception_code`, `name`, `description`, `created_date`, `delivery_date`, `photo`, `created_at`, `updated_at`, `courses_id`) VALUES
(1, 'Mat1a0000', 'Progresiones aritmeticas', 'Resolver antes de la fecha', '2022-06-07', '2022-06-14', '1654719509.jpg', '2022-06-07 22:10:33', '2022-06-09 00:18:29', 1),
(2, 'Mat1a00002', 'Fraccciones', 'Resolver hasta la numero 5', '2022-06-07', '2022-06-14', '1654719456.jpg', '2022-06-08 08:49:56', '2022-06-09 00:17:36', 1),
(4, 'Mat1a00003', 'Ecuaciones', 'Resuelve cada una de los ejercicios y parea con los resultados de la derecha', '2022-06-08', '2022-06-15', '1654719384.jpg', '2022-06-09 00:16:24', '2022-06-09 00:16:24', 1),
(5, 'CO1B00001', 'Elementos de la comunicación', 'Identifica los elementos de la comunicación', '2022-06-08', '2022-06-15', '1654727299.jpg', '2022-06-09 02:28:19', '2022-06-24 05:58:11', 11),
(36, 'CO2A00001', 'Tipos de comunicación', 'Completar segun el tipo de comunicación', '2022-09-12', '2022-09-13', '1664558661.jpg', '2022-09-30 21:24:21', '2022-09-30 21:24:21', 53),
(17, 'CO1A00001', 'La comunicación', 'Rellenar los campos vacios', '2022-07-07', '2022-07-14', '1657225005.jpeg', '2022-07-08 00:16:45', '2022-07-08 00:16:45', 2),
(9, 'AC1B00001', 'Arte y Cultura', 'Rellenar el cuadro de siglo XIX', '2022-06-14', '2022-06-22', '1666188040.jpg', '2022-06-14 21:45:07', '2022-10-19 18:00:40', 19),
(14, 'AC1A00002', 'arte contemporaneo', 'realizar las preguntas', '2022-06-23', '2022-07-02', '1666184016.jpg', '2022-06-24 06:27:06', '2022-10-19 16:53:36', 10),
(12, 'AC1A00001', 'Siglo XX en españa', 'Desarrollar lo requerido', '2022-06-21', '2022-06-28', '1655831811.jpg', '2022-06-21 21:16:51', '2022-06-21 21:16:51', 10),
(13, 'AC1C00001', 'Amancaes', 'Desarrollar lo requerido', '2022-06-21', '2022-06-28', '1655831901.jpg', '2022-06-21 21:18:21', '2022-06-21 21:18:21', 29),
(18, 'CO1B00001', 'Canal de Comunicación', 'Identificar los canales de comunicación', '2022-07-07', '2022-07-14', '1657225209.jpeg', '2022-07-08 00:20:09', '2022-07-08 00:20:09', 38),
(19, 'CO1C00001', 'Formas Verbales', 'Encuentra las formas verbales', '2022-07-07', '2022-07-14', '1657225380.jpeg', '2022-07-08 00:23:00', '2022-07-08 00:23:00', 39),
(20, 'MA1A00001', 'Reloj', 'Coloca las manijas del reloj donde corresponda', '2022-07-07', '2022-07-14', '1657225515.jpeg', '2022-07-08 00:25:15', '2022-07-08 00:25:15', 22),
(21, 'MA1B00001', 'Multiplicación', 'Desarrolla la multiplicación', '2022-07-07', '2022-07-14', '1657225685.jpeg', '2022-07-08 00:28:05', '2022-07-08 00:28:05', 12),
(22, 'MA1C00001', 'Multiples', 'Desarrolla los ejercicios', '2022-07-07', '2022-07-14', '1657226027.jpeg', '2022-07-08 00:33:47', '2022-07-08 00:33:47', 34),
(23, '1/3', 'A', 'Aaa', '2022-08-25', '2022-08-31', '1661476982.jpeg', '2022-08-26 05:23:02', '2022-08-26 05:23:02', 10),
(24, 'AC1B00008', 'Prueba', 'DescPrueba', '2022-08-29', '2022-08-31', '1661822763.jfif', '2022-08-30 05:24:59', '2022-08-30 05:26:03', 19),
(25, 'EF3A00001', 'Saltos largos', 'Conceptos de salto largo', '2022-09-20', '2022-09-23', '1663686944.jpg', '2022-09-20 19:15:44', '2022-09-20 19:15:44', 47),
(26, 'AG3A00001', 'Maximizar', 'Ejercicios', '2022-09-21', '2022-09-21', '1663687803.jpeg', '2022-09-20 19:30:03', '2022-09-20 19:30:03', 48),
(27, 'AG3A00002', 'Prueba', 'AAAAAAAAAA', '2022-09-20', '2022-09-23', '1663695246.jpeg', '2022-09-20 21:34:06', '2022-09-20 21:34:06', 48),
(28, 'AC1B00005', 'Prueba', 'AAAAAAA', '2022-09-20', '2022-09-24', '1663698127.pdf', '2022-09-20 22:15:45', '2022-09-20 22:22:07', 19),
(29, 'AC1B00006', 'Arte', 'Pintar el dibujo', '2022-09-21', '2022-09-25', '1663766404.jpeg', '2022-09-21 17:20:04', '2022-09-21 17:20:04', 19),
(30, 'AC1B00007', 'Tarea', 'Desarrollar', '2022-09-21', '2022-09-25', '1663767961.jpeg', '2022-09-21 17:46:01', '2022-09-21 17:46:01', 19),
(31, 'AC1B00009', 'Ejemplo', 'AAAAAAAA', '2022-09-22', '2022-09-29', '1663863639.jpeg', '2022-09-22 20:20:39', '2022-09-22 20:20:39', 19),
(32, 'AC1B00010', 'Arte', 'Pintar', '2022-09-22', '2022-09-27', '1663867265.jpg', '2022-09-22 21:21:05', '2022-09-22 21:21:05', 19),
(33, 'AC1B00011', 'Arte y cultura', 'Pintar', '2022-09-22', '2022-09-27', '1663868465.jpg', '2022-09-22 21:41:05', '2022-09-22 21:41:05', 19),
(34, 'AC1B00012', 'Arte', 'Dibujar', '2022-09-22', '2022-09-29', '1663877760.jpeg', '2022-09-23 00:16:00', '2022-09-23 00:16:00', 19),
(35, 'AC1A00021', 'Arte', 'Pintar el dibujo', '2022-09-23', '2022-09-29', '1664399895.jpg', '2022-09-23 20:04:21', '2022-09-29 01:18:15', 19),
(37, 'CO2A00002', 'Elemento de la comunicación', 'Correlaciona los elementos de la comunicación con su concepto adecuado.', '2022-09-12', '2022-09-13', '1664558844.jpg', '2022-09-30 21:27:24', '2022-09-30 21:27:24', 53),
(38, 'ET2A00001', 'Monitor', 'Describir las partes del monitor y su funcionalidad.', '2022-09-12', '2022-09-13', '1664561143.jpg', '2022-09-30 22:05:43', '2022-09-30 22:05:43', 54),
(39, 'MA5A00001', 'Practica 01 - Probabilidades', 'Resolver los ejercicios hasta la fecha indicada.', '2022-09-13', '2022-09-14', '1664564131.jpg', '2022-09-30 22:55:31', '2022-09-30 22:55:31', 49),
(40, 'MA5B00001', 'Practica 03 - Ecuaciones', 'Resolver los ejercicios hasta la fecha indicada.', '2022-09-13', '2022-09-14', '1664564946.jpg', '2022-09-30 23:09:06', '2022-09-30 23:09:06', 50),
(41, 'ET1A00001', 'Examen de Computación', 'Menciona las partes de la computadora', '2022-09-14', '2022-09-15', '1664568190.jpg', '2022-10-01 00:03:10', '2022-10-01 00:03:10', 51),
(42, 'ET1B00001', 'Practica sobre Informatica', 'Responda todas las preguntas', '2022-09-14', '2022-09-15', '1664568897.png', '2022-10-01 00:14:57', '2022-10-01 00:14:57', 52),
(43, 'ET4B00001', 'Conoce la ventana de Word', 'Escribir las partes de la ventana de word', '2022-09-15', '2022-09-16', '1664569859.jpg', '2022-10-01 00:30:59', '2022-10-01 00:30:59', 58),
(44, 'ET4A00001', 'Funciones de Word', 'Describir las funciones de Word', '2022-09-15', '2022-09-16', '1664570478.jpg', '2022-10-01 00:41:18', '2022-10-01 00:41:18', 57),
(45, 'MA3B00001', 'Practica 11 - Distribución numerica', 'Resolver lo ejercicios de distribucion numerica.', '2022-09-16', '2022-09-17', '1664571236.jpg', '2022-10-01 00:53:56', '2022-10-01 00:53:56', 56),
(46, 'MA3A00001', 'Practica de Progresiones numericas', 'Resolver los ejercicios correspondientes', '2022-09-16', '2022-09-17', '1664571805.jpg', '2022-10-01 01:03:25', '2022-10-01 01:03:25', 55);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `teachers`
--

CREATE TABLE `teachers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `DNI` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `specialization` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `teachers`
--

INSERT INTO `teachers` (`id`, `DNI`, `name`, `surname`, `email`, `number_phone`, `specialization`, `is_active`, `created_at`, `updated_at`) VALUES
(1, '45278478', 'Luis', 'Marquez Medina', 'mmedina@salesiano.edu.pe', '985075184', 'comunicación', 1, '2022-06-07 22:02:11', '2022-07-05 22:57:08'),
(2, '48962578', 'Miguel', 'Alfaro Mendez', 'amendez@admin.com', '965848578', 'comunicación', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(3, '44578914', 'Rosa', 'Paucar Barzola', 'pbarzola@admin.com', '965245879', 'comunicación', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(4, '24578146', 'Jhony', 'Taboada Ruiz', 'truiz@admin.com', '999225478', 'Matemática', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(5, '45781436', 'Cielo', 'Marcos Damas', 'mdamas@admin.com', '985745863', 'Matemática', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(6, '24578917', 'Juan', 'Puente Tomas', 'jpuente@salesiano.edu.pe', '915236478', 'Matemática', 1, '2022-06-07 22:02:11', '2022-07-05 22:38:22'),
(7, '45248779', 'Juan', 'Quispe Perez', 'qperez@admin.com', '942615378', 'Ciencia y Tecnología', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(8, '24581369', 'Elsa', 'Aquino Inga', 'ainga@admin.com', '965723845', 'Ciencia y Tecnología', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(9, '45217869', 'Hair', 'Gutarra Tobar', 'gtobar@admin.com', '986145237', 'Ciencia y Tecnología', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(10, '24578968', 'Tamara', 'Quilca Atoc', 'qatoc@admin.com', '951753638', 'Ciencias Sociales', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(11, '30621727', 'Pancha', 'Rocar Barzola', 'proca@admin.com', '953647150', 'Ciencias Sociales', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(12, '29672544', 'Jhony', 'Matiaz Lazaro', 'jmatiaz@admin.com', '951355078', 'Ciencias Sociales', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(13, '78723362', 'Juana', 'Lopez Damas', 'jlopez@admin.com', '949063006', 'Desarrollo Personal Ciudadanía y Cívica', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(14, '87774179', 'Carlos', 'Barzola Quispe', 'cquispe@admin.com', '946770934', 'Desarrollo Personal Ciudadanía y Cívica', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(15, '76824996', 'Juan Carlos', 'Perez Santa', 'jcperez@admin.com', '944478862', 'Desarrollo Personal Ciudadanía y Cívica', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(16, '75875814', 'Lucas', 'James Inga', 'ljames@admin.com', '942186790', 'Educación para el Trabajo', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(17, '24926631', 'Santos', 'Santillana Cosme', 'ssantillana@admin.com', '939894718', 'Educación para el Trabajo', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(18, '33977448', 'Tereza', 'Cosme Atocer', 'tcosme@admin.com', '937602646', 'Educación para el Trabajo', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(19, '23028266', 'Candy', 'Tosillas Barzola', 'ctosillaz@admin.com', '935310574', 'Educación Física', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(20, '52079083', 'Maycol', 'Taboada Takay', 'mTaboadat@admin.com', '933018502', 'Educación Física', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(21, '51129900', 'Rene', 'Sarmiento Diaz', 'rsarmiento@admin.com', '930726430', 'Educación Física', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(22, '20180718', 'Cesar', 'Diaz Lopez', 'cdiaz@admin.com', '928434358', 'Educación Religiosa', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(23, '49231535', 'Elizabeth', 'Santana Cosme', 'esantana@admin.com', '926142286', 'Educación Religiosa', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(24, '68282352', 'Edit', 'Caracuzma Lazo', 'ecaracuzma@admin.com', '923850214', 'Educación Religiosa', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(25, '67333169', 'Edison', 'Mata Meza', 'ematar@admin.com', '921558142', 'Arte y Cultura', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(26, '76383987', 'Cristian', 'Avila Santana', 'cavila@salesiano.edu.pe', '919266070', 'Arte y Cultura', 1, '2022-06-07 22:02:11', '2022-06-13 19:07:30'),
(27, '75434804', 'Sandy', 'Rojas Barzola', 'srojas@admin.com', '916973998', 'Arte y Cultura', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(28, '44485621', 'Roger', 'Herrera Tacay', 'rherrera@admin.com', '914681927', 'Ingles', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(29, '43536439', 'Micaela', 'Haro Damas', 'mharo@admin.com', '912389855', 'Ingles', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(30, '42587256', 'Solinda', 'Rola Teresa', 'srola@admin.com', '910097783', 'Ingles', 1, '2022-06-07 22:02:11', '2022-06-07 22:02:11'),
(31, '54676567', 'Wander', 'Carvajal Peres', 'wcarbajal@gmail.com', '998608345', 'Educación Fisica', 1, '2022-09-20 18:56:22', '2022-09-20 19:12:10'),
(32, '19898786', 'Lucas', 'Cahuaya Meza', 'lcahuaya@gmail.com', '985075184', 'Algebra', 1, '2022-09-20 19:24:31', '2022-09-20 19:24:31'),
(33, '48217160', 'Juan Alberto', 'Huaman Peña', 'jhuaman@gmail.com', '998608340', 'Matemática', 1, '2022-09-30 20:10:38', '2022-09-30 20:10:38'),
(34, '48217161', 'Noe Isac', 'Huaman Tupac', 'nhuaman@gmail.com', '998608341', 'Matemática', 1, '2022-09-30 20:10:38', '2022-09-30 20:10:38'),
(35, '48217162', 'Luis', 'Enrique Vega', 'lenrrique@gmail.com', '998608342', 'Educación para Trabajo', 1, '2022-09-30 20:10:38', '2022-09-30 20:10:38'),
(36, '48217163', 'Rajeer', 'Boza Hilario', 'rboza@gmail.com', '998608343', 'Educación para Trabajo', 1, '2022-09-30 20:10:38', '2022-09-30 20:10:38'),
(37, '48217164', 'Janeth Y.', 'Poma Hilario', 'jpoma@gmail.com', '998608344', 'Comunicación', 1, '2022-09-30 20:10:38', '2022-09-30 20:10:38'),
(38, '48217165', 'Nelson', 'Campos Arca', 'ncampos@gmail.com', '998608345', 'Educación para Trabajo', 1, '2022-09-30 20:10:38', '2022-09-30 20:10:38'),
(39, '48217166', 'Cesar', 'Palacios Porras', 'cpalacios@gmail.com', '998608346', 'Matemática', 1, '2022-09-30 20:10:38', '2022-09-30 20:10:38'),
(40, '48217167', 'Carolina', 'Humani Nolasco', 'chuamani@gmail.com', '998608347', 'Matemática', 1, '2022-09-30 20:10:38', '2022-09-30 20:10:38'),
(41, '48217168', 'Liliana', 'Fernandez Tovar', 'lfernandez@gmail.com', '998608348', 'Educación para Trabajo', 1, '2022-09-30 20:10:38', '2022-09-30 20:10:38'),
(42, '48217169', 'Fredy', 'Fernandez Tovar', 'ffernandez@gmail.com', '998608349', 'Educación para Trabajo', 1, '2022-09-30 20:10:38', '2022-09-30 20:10:38');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tutors`
--

CREATE TABLE `tutors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `DNI` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `tutors`
--

INSERT INTO `tutors` (`id`, `DNI`, `name`, `surname`, `email`, `number_phone`, `is_active`, `created_at`, `updated_at`) VALUES
(1, '45344945', 'Sonia', 'Sanchez Piña', 'sanche@gmail.com', '998608456', 0, '2022-06-07 22:04:18', '2022-09-23 18:03:25'),
(2, '68868786', 'Sonia', 'Sanchez Piña', 'SanchezPina@gmail.com', '998612344', 1, '2022-06-08 20:36:22', '2022-09-23 18:04:13'),
(3, '64343554', 'Laura', 'Alfaro Luca', 'AlfaroLuca@gmail.com', '988778658', 0, '2022-06-08 20:36:22', '2022-06-16 09:10:31'),
(4, '68864646', 'Juana', 'Yantas Peña', 'AquinoPena@gmail.com', '957485767', 1, '2022-06-08 20:36:22', '2022-06-17 01:14:55'),
(5, '78868786', 'Pedro', 'Jiménez Soto', 'BarzolaSoto@gmail.com', '975875354', 1, '2022-06-08 20:36:22', '2022-06-17 03:50:48'),
(6, '34868786', 'Rocio', 'Gutarra Sanchez', 'GutarraSanchez@gmail.com', '934344344', 1, '2022-06-08 20:36:22', '2022-06-08 20:36:22'),
(7, '77676886', 'Ruben', 'Marcos Damas', 'MarcosDamas@gmail.com', '987676765', 1, '2022-06-08 20:36:22', '2022-06-08 20:36:22'),
(8, '98768786', 'Mario', 'Marquez Soto', 'MarquezSoto@gmail.com', '987876754', 1, '2022-06-08 20:36:22', '2022-06-08 20:36:22'),
(9, '98987746', 'Marco', 'Paucar Briarte', 'PaucarBriarte@gmail.com', '923456765', 1, '2022-06-08 20:36:22', '2022-06-08 20:36:22'),
(10, '44568786', 'Luis', 'Quilca Lucas', 'QuilcaLucas@gmail.com', '987898921', 1, '2022-06-08 20:36:22', '2022-06-08 20:36:22'),
(11, '56565686', 'Paul', 'Serva Yantas', 'pserva@gmail.com', '985075184', 1, '2022-06-08 20:36:22', '2022-09-23 17:21:12'),
(12, '55645786', 'Carlos', 'Taboada Ruiz', 'TaboadaRuiz@gmail.com', '912345876', 1, '2022-06-08 20:36:22', '2022-06-08 20:36:22');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `roles_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `roles_id`) VALUES
(1, 'Sandro Palian Perez', 'spalian@salesiano.edu.pe', '2022-06-04 08:02:06', '$2y$10$RVMuzh3P9O682eGXKGtgiemoZWR8CFhUXoR5REPyV6Yn8DlPoZdfa', NULL, '2022-06-04 08:02:06', '2022-06-08 22:53:09', 1),
(9, 'Luis Marquez Medina', 'mmedina@salesiano.edu.pe', NULL, '$2y$10$/gihNKs2ktxyTKaIo4QdUuJQz/mC75S5ZaTN8j0GAXQM4AKdOhLDq', NULL, '2022-07-05 22:55:15', '2022-07-05 22:57:50', 2),
(8, 'Juan Puente Tomas', 'jpuente@salesiano.edu.pe', NULL, '$2y$10$jkqBaPgNbbFfU9rj8BPuYO0oAhVrdnmjHE7keOyMFPVLcyzpyU/BC', NULL, '2022-07-05 22:26:36', '2022-07-05 22:28:01', 2),
(4, 'Cristian Avila Santana', 'cavila@salesiano.edu.pe', NULL, '$2y$10$EatnbKhGtRLMWvunKqP9F.ttTqclrtuw8Z0gL2Qo11KVXBZRigs7C', NULL, '2022-06-07 21:54:02', '2022-06-08 23:08:27', 2),
(10, 'Wander Carbajal Perez', 'wcarbajal@gmail.com', NULL, '$2y$10$YPII79t91r5F4BJTmYjSjumClp9UQVhLhCzVEP3h/HwXs6gyuzlLm', NULL, '2022-09-20 18:57:57', '2022-09-20 19:11:16', 2),
(11, 'Lucas Cahuaya Meza', 'lcahuaya@gmail.com', NULL, '$2y$10$4/WyzWCeW2f3voyDn21D4ukl0w8jmqdKrL1gVY78sU2hoOR5zHRAC', NULL, '2022-09-20 19:26:28', '2022-09-20 19:26:28', 2),
(12, 'paul', 'sda@gmail.com', NULL, '$2y$10$PiP9ocrBBu8Ap.ETlPfxeuF./vDLaBTQLMbbs9SZRmSvK.SnoUUWi', NULL, '2022-09-29 02:17:21', '2022-09-29 02:17:21', NULL),
(13, 'Juan Alberto	Huaman Peña', 'jhuaman@gmail.com', NULL, '$2y$10$UMAlkBTKFsUpsaCHxW6hAe7c.jlqkqWgWEyxVoiuYVCTKchJLAT5q', NULL, '2022-09-30 20:50:26', '2022-09-30 20:50:26', 2),
(14, 'Noe Isac	Huaman Tupac', 'nhuaman@gmail.com', NULL, '$2y$10$ldE8xXqMQnMlYpWqLXH9CuvPyoc5M2GmuxZqfNOUKwRWyuKJ1LhqO', NULL, '2022-09-30 20:51:12', '2022-09-30 20:51:12', 2),
(15, 'Luis	Enrique Vega', 'lenrrique@gmail.com', NULL, '$2y$10$TBIQ/94jrQ6/fNo/PlkV7.wYN9OmwLY8WdZWCXCwoUFhZ.V1qTqnq', NULL, '2022-09-30 20:51:50', '2022-09-30 20:51:50', 2),
(16, 'Rajeer Boza Hilario', 'rboza@gmail.com', NULL, '$2y$10$wmmnXaQQXyAFGUYWMS3A5eGqdmIBzfIDvNyxSZY5cNiSGVBYy/o6O', NULL, '2022-09-30 20:52:56', '2022-09-30 20:52:56', 2),
(17, 'Janeth Y. Poma Hilario', 'jpoma@gmail.com', NULL, '$2y$10$9mY0Z79FzGs7M7O00KB33uWNIaRw5l9G5rkrRQOHO.wPPF6PeIko2', NULL, '2022-09-30 20:54:25', '2022-09-30 20:54:25', 2),
(18, 'Nelson Campos Arca', 'ncampos@gmail.com', NULL, '$2y$10$Bl4mNQ8pRaadKn9gp7uQHOmCTakFvMlGk7rmEhjE0qpoIyAk/0YQq', NULL, '2022-09-30 20:55:10', '2022-09-30 20:55:10', 2),
(19, 'Cesar Palacios Porras', 'cpalacios@gmail.com', NULL, '$2y$10$7pSH/koqRbPydjIA/feeTuaP56JfAucRFhZ/HsY116zpyQsigULu6', NULL, '2022-09-30 20:56:09', '2022-09-30 20:56:09', 2),
(20, 'Carolina	Humani Nolasco', 'chuamani@gmail.com', NULL, '$2y$10$9ivnnW/J4RlMcbQhajcKteQR0TeFXHJOQETH3tfYRMkl1ZUD7FBBy', NULL, '2022-09-30 20:56:41', '2022-09-30 20:56:41', 2),
(21, 'Liliana Fernandez Tovar', 'lfernandez@gmail.com', NULL, '$2y$10$GVYatAe51HPSBBxmIiaiseiypCilTO.w/VaOI9tCF0fgNrkSF7LVq', NULL, '2022-09-30 20:57:24', '2022-09-30 20:57:24', 2),
(22, 'Fredy Fernandez Tovar', 'ffernandez@gmail.com', NULL, '$2y$10$zmo5HmNhSZpGw1gg8uro6OmceAwgIj/lnG4gBaaJqC8VA2lrNF2uC', NULL, '2022-09-30 20:57:59', '2022-09-30 20:57:59', 2);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `classrooms`
--
ALTER TABLE `classrooms`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `courses_teachers_id_foreign` (`teachers_id`),
  ADD KEY `courses_classrooms_id_foreign` (`classrooms_id`);

--
-- Indices de la tabla `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indices de la tabla `labors`
--
ALTER TABLE `labors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `labors_students_id_foreign` (`students_id`);

--
-- Indices de la tabla `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indices de la tabla `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD KEY `students_tutors_id_foreign` (`tutors_id`);

--
-- Indices de la tabla `student_course`
--
ALTER TABLE `student_course`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_course_students_id_foreign` (`students_id`),
  ADD KEY `student_course_courses_id_foreign` (`courses_id`);

--
-- Indices de la tabla `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tasks_courses_id_foreign` (`courses_id`);

--
-- Indices de la tabla `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tutors`
--
ALTER TABLE `tutors`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_roles_id_foreign` (`roles_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `classrooms`
--
ALTER TABLE `classrooms`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT de la tabla `courses`
--
ALTER TABLE `courses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT de la tabla `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `labors`
--
ALTER TABLE `labors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT de la tabla `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `students`
--
ALTER TABLE `students`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de la tabla `student_course`
--
ALTER TABLE `student_course`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT de la tabla `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT de la tabla `teachers`
--
ALTER TABLE `teachers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT de la tabla `tutors`
--
ALTER TABLE `tutors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
